import unittest
from flask import Flask
from api.routes import routes as routes_blueprint
from api.models import Group, GroupMessage, db
import json

class TestAPI(unittest.TestCase):

    def setUp(self):
        self.app = Flask(__name__)
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.app.register_blueprint(routes_blueprint)
        db.init_app(self.app)
        with self.app.app_context():
            db.create_all()

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def test_create_group(self):
        with self.app.test_client() as client:
            response = client.post('/groups', json={'name': 'Test Group'})
            data = self.get_json(response)
            self.assertEqual(response.status_code, 201)
            self.assertEqual(data['message'], 'Group created successfully')

    def test_list_messages(self):
        # Add test data to the database
        with self.app.app_context():
            group = Group(name='Test Group')
            db.session.add(group)
            db.session.commit()
            message = GroupMessage(message='Test Message', user_id=1, group_id=1)
            db.session.add(message)
            db.session.commit()

        with self.app.test_client() as client:
            response = client.get('/groups/1/messages')
            data = self.get_json(response)
            self.assertEqual(response.status_code, 200)
            self.assertTrue('messages' in data)
            self.assertEqual(len(data['messages']), 1)
            self.assertEqual(data['messages'][0]['message'], 'Test Message')

    def get_json(self, response):
        try:
            return json.loads(response.get_data(as_text=True))
        except json.decoder.JSONDecodeError:
            return None
    def test_create_message(self):
        # Add test data to the database
        with self.app.app_context():
            group = Group(name='Test Group')
            db.session.add(group)
            db.session.commit()

        with self.app.test_client() as client:
            response = client.post('/groups/1/messages', json={'message': 'Test Message'})
            data = self.get_json(response)
            self.assertEqual(response.status_code, 200)
            self.assertEqual(data['message'], 'Message sent successfully')
    
    def test_delete_group(self):
        # Add test data to the database
        with self.app.app_context():
            group = Group(name='Test Group')
            db.session.add(group)
            db.session.commit()

        with self.app.test_client() as client:
            response = client.delete('/groups/1')
            data = self.get_json(response)
            self.assertEqual(response.status_code, 200)
            self.assertEqual(data['message'], 'Group deleted successfully')

    def test_add_member_to_group(self):
        # Add test data to the database
        with self.app.app_context():
            group = Group(name='Test Group')
            db.session.add(group)
            db.session.commit()

        with self.app.test_client() as client:
            response = client.post('/groups/1/members', json={'member_name': 'Test Member'})
            data = self.get_json(response)
            self.assertEqual(response.status_code, 200)
            self.assertEqual(data['message'], 'Member added to group successfully')


if __name__ == '__main__':
    unittest.main()
