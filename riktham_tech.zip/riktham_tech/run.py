
from flask import Flask
from api.routes import routes as routes_blueprint
from api.models import db

app = Flask(__name__, template_folder='./templates', static_folder='./static')

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:rootp@localhost/riktam '
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Optional: Disable modification tracking
app.config['SECRET_KEY'] = 'secret'

app.register_blueprint(routes_blueprint)

if __name__ == '__main__':
    db.init_app(app)
    app.run(debug=True)