
from flask import Blueprint, jsonify, redirect, render_template, request, session, url_for
from flask import jsonify

routes = Blueprint('v1', __name__)


from api.models import Group, GroupMessage, LikeMessage, User, db

@routes.route('/')
def index():
    return render_template('login.html')

# routes.py

@routes.route('/dashboard')
def dashboard():
    if 'username' in session:
        if session['is_admin']:
            return redirect(url_for('v1.admin_dashboard'))
        else:
            return redirect(url_for('v1.user_dashboard'))
    else:
        return redirect(url_for('v1.login'))

@routes.route('/admin/dashboard')
def admin_dashboard():
    if 'username' in session and session['is_admin']:
        return render_template('admin_dashboard.html')
    else:
        return redirect(url_for('v1.login'))

@routes.route('/user/dashboard')
def user_dashboard():
    if 'username' in session and not session['is_admin']:
        return render_template('user_dashboard.html')
    else:
        return redirect(url_for('v1.login'))



# Admin API to create a user (only accessible to admin users)
@routes.route('/admin/create_user', methods=['POST'])
def create_user():
    if 'username' not in session or not session['is_admin']:
        return jsonify({'error': 'Unauthorized access'}), 401
    
    data = request.json
    username = data.get('username')
    password = data.get('password')
    is_admin = data.get('is_admin', False)

    # Check if the username already exists
    if User.query.filter_by(username=username).first():
        return jsonify({'error': 'Username already exists'}), 400

    # Create the user
    new_user = User(username=username, password=password, is_admin=is_admin)
    db.session.add(new_user)
    db.session.commit()

    return jsonify({'message': 'User created successfully'}), 201

# Edit User API
@routes.route('/admin/edit_user', methods=['PUT'])
def edit_user():
    # Get form data
    print(request.json, "request.json")
    user_id = request.json.get('userId')
    new_username = request.json.get('username')
    new_password = request.json.get('password')
    is_admin = bool(request.json.get('isAdmin'))

    # Get the user from the database
    user = User.query.filter_by(id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Update user details
    user.username = new_username
    user.password = new_password
    user.is_admin = is_admin

    # Save changes to the database
    db.session.commit()

    return jsonify({'message': 'User updated successfully'})

# Delete user route (DELETE method)
@routes.route('/admin/delete_user/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    # Find user by user_id
    user = User.query.get(user_id)

    # Check if user exists
    if user:
        # Delete user
        db.session.delete(user)
        db.session.commit()
        return jsonify({'message': 'User deleted successfully'}), 200
    else:
        return jsonify({'error': 'User not found'}), 404


# Authentication API for login
@routes.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')

    # Retrieve the user from the database
    user = User.query.filter_by(username=username).first()

    # Check if user exists and the password is correct
    if user and user.password == password:
        # Store user information in the session
        session['username'] = user.username
        session['is_admin'] = user.is_admin
        return jsonify({'message': 'Logged in successfully'}), 200
    else:
        return jsonify({'error': 'Invalid credentials'}), 401

# Authentication API for logout
@routes.route('/logout', methods=['POST'])
def logout():
    # Clear the session
    session.clear()
    return jsonify({'message': 'Logged out successfully'}), 200




# Groups APIs
@routes.route('/groups', methods=['POST'])
def create_group():
    group_name = request.json.get('name')

    if not group_name:
        return jsonify({'error': 'Group name is required'}), 400

    existing_group = Group.query.filter_by(name=group_name).first()
    if existing_group:
        return jsonify({'error': 'Group with this name already exists'}), 409

    new_group = Group(name=group_name)
    db.session.add(new_group)
    db.session.commit()
    return jsonify({'message': 'Group created successfully'}), 201

@routes.route('/groups/<int:group_id>', methods=['DELETE'])
def delete_group(group_id):
    group = Group.query.get(group_id)

    if not group:
        return jsonify({'error': 'Group not found'}), 404

    db.session.delete(group)
    db.session.commit()
    return jsonify({'message': 'Group deleted successfully'})

@routes.route('/groups/search', methods=['GET'])
def search_groups():
    # Get the search query from the request parameters
    search_query = request.args.get('query')

    # Query the groups based on the search query
    if search_query:
        # Perform case-insensitive search by filtering the groups with names containing the search query
        matched_groups = Group.query.filter(Group.name.ilike(f"%{search_query}%")).all()
    else:
        # If no search query provided, return all groups
        matched_groups = Group.query.all()

    # Convert the matched groups to a list of dictionaries
    groups_list = [{'id': group.id, 'name': group.name} for group in matched_groups]

    # Return the matched groups as JSON response
    return jsonify({'groups': groups_list})
@routes.route('/groups/<int:group_id>/members', methods=['POST'])
def add_member(group_id):
    group = Group.query.get(group_id)

    if not group:
        return jsonify({'error': 'Group not found'}), 404

    member_name = request.json.get('member_name')

    if not member_name:
        return jsonify({'error': 'Member name is required'}), 400

    # Add the member to the group (implementation needed)

    return jsonify({'message': 'Member added to group successfully'})

# Group Messages APIs
@routes.route('/groups/<int:group_id>/messages', methods=['POST'])
def send_message(group_id):
    group = Group.query.get(group_id)

    if not group:
        return jsonify({'error': 'Group not found'}), 404

    message_text = request.json.get('message')

    if not message_text:
        return jsonify({'error': 'Message text is required'}), 400

    # Send message to the group (implementation needed)

    return jsonify({'message': 'Message sent successfully'})


@routes.route('/groups/<int:group_id>/messages/<int:message_id>/like', methods=['POST'])
def like_message(group_id, message_id):
    # Check if the group exists
    group = Group.query.get(group_id)
    if not group:
        return jsonify({'error': 'Group not found'}), 404

    # Check if the message exists in the group
    message = GroupMessage.query.filter_by(id=message_id, group_id=group_id).first()
    if not message:
        return jsonify({'error': 'Message not found in the group'}), 404

    # Get the user ID from the session
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'User not authenticated'}), 401

    # Check if the user already liked the message
    if LikeMessage.query.filter_by(user_id=user_id, message_id=message_id).first():
        return jsonify({'error': 'You already liked this message'}), 400

    # Create a new like for the message
    new_like = LikeMessage(user_id=user_id, message_id=message_id)
    db.session.add(new_like)
    db.session.commit()

    return jsonify({'message': 'Message liked successfully'}), 200

# list users 

@routes.route('/users', methods=['GET'])
def list_users():
    users = User.query.all()

    user_list = [{'id': user.id, 'username': user.username, 'is_admin': user.is_admin} for user in users]

    return jsonify({'users': user_list})

# list messages
@routes.route('/groups/<int:group_id>/messages', methods=['GET'])
def list_messages(group_id):
    group = Group.query.get(group_id)

    if not group:
        return jsonify({'error': 'Group not found'}), 404

    messages = GroupMessage.query.filter_by(group_id=group_id).all()

    message_list = [{'id': message.id, 'message': message.message, 'user_id': message.user_id} for message in messages]

    return jsonify({'messages': message_list})