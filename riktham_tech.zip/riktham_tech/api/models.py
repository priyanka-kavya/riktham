from flask_sqlalchemy import SQLAlchemy 


db = SQLAlchemy()

# User model
class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)

    # Relationships
    group_memberships = db.relationship('GroupMembership', back_populates='user')
    liked_messages = db.relationship('LikeMessage', back_populates='user')

# Group model
class Group(db.Model):
    __tablename__ = 'groups'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)

    # Relationships
    group_memberships = db.relationship('GroupMembership', back_populates='group')
    group_messages = db.relationship('GroupMessage', back_populates='group')
    
    def __repr__(self):
        return f'<Group(id={self.id}, name={self.name})>'

# GroupMembership model
class GroupMembership(db.Model):
    __tablename__ = 'group_memberships'

    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey('groups.id'), primary_key=True)

    # Relationships
    user = db.relationship('User', back_populates='group_memberships')
    group = db.relationship('Group', back_populates='group_memberships')

# GroupMessage model
class GroupMessage(db.Model):
    __tablename__ = 'group_messages'

    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    group_id = db.Column(db.Integer, db.ForeignKey('groups.id'), nullable=False)

    # Relationships
    user = db.relationship('User')
    group = db.relationship('Group')
    likes = db.relationship('LikeMessage', back_populates='message')

# LikeMessage model
class LikeMessage(db.Model):
    __tablename__ = 'like_messages'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message_id = db.Column(db.Integer, db.ForeignKey('group_messages.id'), nullable=False)

    # Relationships
    user = db.relationship('User', back_populates='liked_messages')
    message = db.relationship('GroupMessage', back_populates='likes')

