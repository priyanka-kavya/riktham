// Function to send a message via AJAX
function sendMessage(url, data) {
    $.ajax({
        type: 'POST',
        url: url,
        contentType: 'application/json',
        data: JSON.stringify(data),
        success: function(response) {
            // Handle success (if needed)
        },
        error: function(xhr, status, error) {
            console.error('Error sending message:', error);
        }
    });
}

// Function to update the chat interface with new messages
function updateChat(messages, containerId) {
    var container = document.getElementById(containerId);
    container.innerHTML = ''; // Clear previous messages

    messages.forEach(function(message) {
        var messageElement = document.createElement('div');
        messageElement.textContent = message;
        container.appendChild(messageElement);
    });
}

// Function to handle form submission (sending messages)
function handleFormSubmit(formId, url, containerId) {
    var form = document.getElementById(formId);
    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent page reload

        var messageInput = document.getElementById(formId + '-input');
        var message = messageInput.value.trim();
        if (message) {
            sendMessage(url, { message: message });
            messageInput.value = ''; // Clear input field
        }
    });
}

// Call handleFormSubmit() for user chat and group chat forms
handleFormSubmit('user-message-form', '/user/chat', 'user-chat-messages');
handleFormSubmit('group-message-form', '/group/chat', 'group-chat-messages');

// Function to periodically update chat messages (if needed)
function updateChatPeriodically(url, containerId, interval) {
    setInterval(function() {
        $.get(url, function(messages) {
            updateChat(messages, containerId);
        });
    }, interval);
}

// Call updateChatPeriodically() to update chat messages periodically (if needed)
updateChatPeriodically('/user/chat/messages', 'user-chat-messages', 5000); // Example URL and interval for user chat
updateChatPeriodically('/group/chat/messages', 'group-chat-messages', 5000); // Example URL and interval for group chat
